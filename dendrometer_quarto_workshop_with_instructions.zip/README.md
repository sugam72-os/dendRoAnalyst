# Dendrometer Data Analysis Workshop

This is a Quarto/RStudio workshop project generated from the uploaded R function files.

## Structure

- `R/functions/`: all uploaded function files, copied unchanged.
- `R/helpers/source_workshop_functions.R`: helper to source all function files.
- `00_setup.R`: package loading, function sourcing, output folders, and data loading.
- `data/raw/`: place dendrometer and climate data here.
- `modules/`: Quarto workshop lessons.
- `reference/function_catalogue.csv`: all detected functions and argument variations.
- `reference/public_function_catalogue.csv`: main workshop-facing functions.
- `outputs/`: generated figures, tables, and saved objects.

## Start

1. Open `dendrometer-workshop.Rproj` in RStudio.
2. Run `install.R` once.
3. Put dendrometer and climate files in `data/raw/`, or use explicit paths.
4. Run:

```r
source("00_setup.R")
workshop_data <- load_workshop_data()
dm <- workshop_data$dm
clim <- workshop_data$clim
```

## Render the Quarto book

```r
quarto::quarto_render(".")
```

The Quarto pages use `eval: false` by default so that the book can render before data are added. During the workshop, run the chunks interactively in RStudio.
