# Public function quick reference


## 1 Import, quality control, resampling, gaps

- `aggregate_data(df, target_info, value, by_original)`
- `boot_mean_delta_fast(delta, n_boot)`
- `correct_gap_end_jumps(value, fit, pi_lo, pi_hi, interp_flag, original_values, time_vec, jump_threshold, adjustment_method = c("window_median", "point_diff"), adjust_window = 5, set_jump_point_na = FALSE)`
  - Variations: adjustment_method: window_median, point_diff
- `daily_case_differences_fast(idx_days, truth, fit)`
- `dendro.resample(df, by, value = "mean", method = c("auto", "aggregate", "interpolate"))`
  - Variations: method: auto, aggregate, interpolate
- `dendro.truncate(df, CalYear, DOY)`
- `dm.na.interpolation(df, resolution, fill = FALSE, method = "spline", assess = FALSE, assess_lengths_hours = seq(6, 72, by = 6), assess_samples_per_length = 10, assess_buffer_hours = 6, assess_seed = NULL, verbose = FALSE)`
- `estimate_jump_offset(x, j, adjustment_method = c("window_median", "point_diff"), adjust_window = 5)`
  - Variations: adjustment_method: window_median, point_diff
- `estimate_jump_offset_gap(x, j, adjustment_method = c("window_median", "point_diff"), adjust_window = 5)`
  - Variations: adjustment_method: window_median, point_diff
- `i.jump.locator(df, TreeNum, detection_method = c("manual", "auto"), manual_threshold = NULL, auto_method_penalty = 10, adjustment_method = c("window_median", "point_diff"), adjust_window = 5, plot_window = 20, auto_every_second = TRUE, set_jump_point_na = FALSE)`
  - Variations: detection_method: manual, auto; adjustment_method: window_median, point_diff
- `interpolate_one_series(a_raw, ref_mat, ref_ok, niMethod, n_boot, tiny = 1e-6)`
- `interpolate_to_grid(df, target_info)`
- `jump.locator(df, detection_method = c("manual", "auto"), manual_threshold = NULL, auto_method_penalty = 10, adjustment_method = c("window_median", "point_diff"), adjust_window = 5, auto_every_second = TRUE, set_jump_point_na = FALSE)`
  - Variations: detection_method: manual, auto; adjustment_method: window_median, point_diff
- `network.interpolation(df, referenceDF, niMethod = c("proportional", "linear"), n_boot = 1000, return_flags = TRUE, return_pi = TRUE, pi_for_all = FALSE, return_fit = FALSE, assess = FALSE, assess_lengths_steps = c(1, 2, 3, 6, 12, 24), assess_samples_per_length = 20, assess_buffer_steps = 1, assess_seed = NULL, assess_use_only_observed = TRUE, progress = interactive(), correct_gap_jumps = FALSE, jump_threshold = NULL, jump_adjustment_method = c("window_median", "point_diff"), jump_adjust_window = 5, jump_set_point_na = FALSE)`
  - Variations: niMethod: proportional, linear; assess_lengths_steps: 1, 2, 3, 6, 12, 24; jump_adjustment_method: window_median, point_diff
- `plot.dm_na_interpolation(x, type = NULL, series = NULL, metric = "MdAPE", original = NULL, start = NULL, end = NULL, free_y = TRUE, ncol = 1, facet = TRUE, empty_gaps = c("plot", "error"), ...)`
  - Variations: empty_gaps: plot, error
- `plot.network_interpolation(x, type = c("interpolation", "uncertainty", "availability", "summary", "validation", "coverage", "compare", "seasonal_error"), series = NULL, start = NULL, end = NULL, show_pi = TRUE, show_fit = FALSE, free_y = TRUE, ncol = 1, summary_metric = c("n_imputed", "n_remaining_na", "n_missing_input", "mean_pi_width", "median_pi_width", "mean_ref_n", "median_ref_n", "n_gap_jumps_removed", "max_abs_gap_jump"), validation_metric = c("MAE", "MAPE", "MdAPE", "RMSE", "Bias", "Success_rate", "Mean_PI_width", "Mean_ref_n", "End_value_abs_diff", "Max_abs_diff_within_gap"), seasonal_metric = c("mean_error", "mean_abs_error", "mean_abs_pct_error", "rmse", "coverage"), compare_colour = c("series", "gap_steps"), facet = TRUE, empty = c("plot", "error"), ...)`
  - Variations: type: interpolation, uncertainty, availability, summary, validation, coverage, compare, seasonal_error; summary_metric: n_imputed, n_remaining_na, n_missing_input, mean_pi_width, median_pi_width, mean_ref_n, median_ref_n, n_gap_jumps_removed, max_abs_gap_jump; validation_metric: MAE, MAPE, MdAPE, RMSE, Bias, Success_rate, Mean_PI_width, Mean_ref_n, End_value_abs_diff, Max_abs_diff_within_gap; seasonal_metric: mean_error, mean_abs_error, mean_abs_pct_error, rmse, coverage; compare_colour: series, gap_steps; empty: plot, error
- `plot_dm_assessment(x, metric = "MdAPE", series = NULL, facet = TRUE)`
- `plot_dm_gaps(x, series = NULL, empty_gaps = c("plot", "error"))`
  - Variations: empty_gaps: plot, error
- `plot_dm_interpolation(x, original = NULL, series = NULL, start = NULL, end = NULL, free_y = TRUE, ncol = 1)`
- `plot_jump_series(time_vec, value_vec, jump_times = NULL, title = "", line_color = "red")`
- `read.dendrometer(file, sep = NULL, dec = NULL, datetime_col = 1, date_col = NULL, time_col = NULL, tz = "UTC", sheet = NULL, range = NULL, na = c("", "NA", "NaN", "nan", "null", "NULL", "-9999"), assume_midnight = TRUE, orders = NULL, excel_dates = c("auto", "none", "1900", "1904"), drop_dup_times = TRUE, detect_resolution = FALSE, return_report = FALSE, quiet = TRUE)`
  - Variations: na: , , , , , , , , , , , ; excel_dates: auto, none, 1900, 1904
- `reso_dm(input_time)`
- `smooth_dm(time, dm, resolution_min = NULL, method = c("median_mean","pspline","sg","ema","loess"), window_hours = 3, sg_order = 2, ema_alpha = NULL)`
  - Variations: method: median_mean, pspline, sg, ema, loess

## 2 Standardisation and detrending

- `assign_season_year(time, season_type, CS_doys = NULL)`
- `dm.detrend.fit(x, series = NULL, seasons = NULL, epsilon = 1e-6, keep_na_rows = FALSE)`
- `dm_standardize(df, season_type = c("NH", "SH", "CS"), CS_doys = NULL, method = c("center", "amplitude", "robust_amplitude", "minmax", "zscore", "robust_zscore", "percentile"), ref_type = c("first_value", "first_n_days", "ref_window"), ref_n_days = 7, ref_doys = NULL, q_low = 0.05, q_high = 0.95)`
  - Variations: season_type: NH, SH, CS; method: center, amplitude, robust_amplitude, minmax, zscore, robust_zscore, percentile; ref_type: first_value, first_n_days, ref_window
- `in_doy_window(doy, doy_window)`
- `mean_detrended.dm(detrended_dm, series = NULL, ac1.remove = TRUE, robust.mean = TRUE, trim = 0.15, seasonal_rescale = TRUE)`
- `percentile_scale(x)`
- `plot.dm_detrended(x, y = NULL, type = c("compare", "fit", "residual", "detrended", "boxplot"), series = NULL, seasons = NULL, x_axis = c("default", "date", "season_day", "doy"), facet_by = c("series", "season", "none"), ncol = NULL, box_group = c("series", "season"), show_observed = TRUE, show_fitted = TRUE, point_alpha = 0.7, line_width = 0.8, legend_position = "right", ...)`
  - Variations: type: compare, fit, residual, detrended, boxplot; x_axis: default, date, season_day, doy; facet_by: series, season, none; box_group: series, season
- `plot.dm_standardized(x, y = NULL, trees = "all", type = c("series", "seasonal", "heatmap", "boxplot"), x_axis = c("time", "doy", "season_doy"), facet_by = c("tree", "season_year", "none"), legend_by = c("season_year", "tree", "none"), in_season_only = TRUE, box_group = c("tree", "season_year"), alpha = 0.8, line_size = 0.45, point_size = 1.6, ...)`
  - Variations: type: series, seasonal, heatmap, boxplot; x_axis: time, doy, season_doy; facet_by: tree, season_year, none; legend_by: season_year, tree, none; box_group: tree, season_year
- `plot.mean_dm_detrended(x, y = NULL, type = c("series", "seasonal", "boxplot"), value = c("both", "STD_DDM", "RES_DDM"), seasons = NULL, x_axis = c("default", "date", "doy", "season_day"), facet_by = c("none", "season", "metric"), ncol = NULL, box_group = c("metric", "season"), alpha = 0.8, line_width = 0.8, point_size = 1.4, legend_position = "right", ...)`
  - Variations: type: series, seasonal, boxplot; value: both, STD_DDM, RES_DDM; x_axis: default, date, doy, season_day; facet_by: none, season, metric; box_group: metric, season

## 3 Daily summaries and phase extraction

- `cummax_na(x)`
- `daily.data(df, TreeNum)`
- `dm_event_climate(x, clim_df, event = c("phase_start", "phase_end", "max_twd"), phase = "all", windows = c(0, 1, 3, 6, 12, 24, 48), mean_vars = NULL, max_vars = NULL, min_vars = NULL, sum_vars = NULL, median_vars = NULL, instant_vars = NULL, instant_match = c("nearest", "previous", "next"))`
  - Variations: event: phase_start, phase_end, max_twd; windows: 0, 1, 3, 6, 12, 24, 48; instant_match: nearest, previous, next
- `dm_event_climate_summary(event_data, climate_var, group_var = c("Phase", "event_type"), by = c("none", "month", "month_of_year", "year"), Year = NULL, DOY = NULL)`
  - Variations: group_var: Phase, event_type; by: none, month, month_of_year, year
- `dm_event_climate_test(event_data, climate_var, group_var = c("Phase", "event_type"), by = c("none", "month", "month_of_year", "year"), Year = NULL, DOY = NULL, method = c("auto", "anova", "kruskal", "t.test", "wilcox"))`
  - Variations: group_var: Phase, event_type; by: none, month, month_of_year, year; method: auto, anova, kruskal, t.test, wilcox
- `dm_join_daily_clim(daily_obj, clim_daily)`
- `dm_join_phase_clim(x, clim_df, mean_vars = NULL, min_vars = NULL, max_vars = NULL, sum_vars = NULL, median_vars = NULL, suffix = "_phase")`
- `dm_join_subdaily_clim(x, clim_sub)`
- `dm_plot_climate(x, climate_var, metric_var = NULL, scale = c("auto", "daily", "cycle", "point"), type = c("timeseries", "boxplot", "violin", "both", "relation"), group_var = NULL, Year = NULL, DOY = NULL, point_alpha = 0.6, add_smooth = FALSE, temporal = NULL)`
  - Variations: scale: auto, daily, cycle, point; type: timeseries, boxplot, violin, both, relation
- `dm_plot_climate_compare(x, climate_vars = NULL, numeric_vars = NULL, scale = c("auto", "daily", "cycle", "point"), type = c("timeseries", "boxplot", "violin", "both", "cor_heatmap", "regression_heatmap"), group_var = NULL, Year = NULL, DOY = NULL, box_scales = c("free_y", "fixed"), cor_method = c("pearson", "spearman", "kendall"), use_pairwise = TRUE, regression_stat = c("r.squared", "slope", "p.value"), point_alpha = 0.5, show_values = FALSE, temporal = NULL)`
  - Variations: scale: auto, daily, cycle, point; type: timeseries, boxplot, violin, both, cor_heatmap, regression_heatmap; box_scales: free_y, fixed; cor_method: pearson, spearman, kendall; regression_stat: r.squared, slope, p.value
- `pair_reg_stat(xv, yv, what = c("r.squared", "slope", "p.value"))`
  - Variations: what: r.squared, slope, p.value
- `phase.sc(df, TreeNum, smoothing=NULL)`
- `phase.zg(df, TreeNum, smoothing = NULL, beta = 0.1)`
- `plot.SC_output(x, y = NULL, DOY = NULL, Year = NULL, type = c("points", "ribbon", "transition", "balance", "increment", "frequency", "heatmap", "boxplot"), temporal = c("raw", "daily", "monthly"), x_axis = c("time", "doy"), balance_mode = c("time_of_day", "duration"), stat = c("Duration_h", "Duration_m", "Magnitude", "rate"), phase = c("all", "Shrinkage", "Expansion", "Increment"), cols = c("#fee8c8", "#fdbb84", "#e34a33"), phNames = c("Shrinkage", "Expansion", "Increment"), transition_linetype = "dashed", transition_alpha = 0.55, singleton_as_points = TRUE, ...)`
  - Variations: type: points, ribbon, transition, balance, increment, frequency, heatmap, boxplot; temporal: raw, daily, monthly; x_axis: time, doy; balance_mode: time_of_day, duration; stat: Duration_h, Duration_m, Magnitude, rate; phase: all, Shrinkage, Expansion, Increment; cols: #fee8c8, #fdbb84, #e34a33; phNames: Shrinkage, Expansion, Increment
- `plot.SC_output_clim(x, y = NULL, ..., climate_var = NULL, climate_vars = NULL, numeric_vars = NULL, compare = FALSE, temporal = NULL)`
- `plot.ZG_output(x, y = NULL, DOY = NULL, Year = NULL, view = NULL, type = c("gro_twd", "phase_ribbon", "transition", "twd", "abr", "phase_summary", "balance", "boxplot"), temporal = c("raw", "daily", "monthly"), x_axis = c("time", "doy"), stat = c("Duration_h", "Magnitude", "rate", "max.twd", "Avg.twd", "STD.twd", "AUC.load", "AUC.total", "ABr.value"), phase = c("auto", "TWD", "GRO", "all"), box_group = c("period", "month_of_year", "doy"), twd_fun = c("mean", "max"), gro_fun = c("max", "mean"), transition_linetype = "dashed", transition_alpha = 0.55, cols = c(TWD = "red", GRO = "blue"), singleton_as_points = TRUE, ...)`
  - Variations: type: gro_twd, phase_ribbon, transition, twd, abr, phase_summary, balance, boxplot; temporal: raw, daily, monthly; x_axis: time, doy; stat: Duration_h, Magnitude, rate, max.twd, Avg.twd, STD.twd, AUC.load, AUC.total, ABr.value; phase: auto, TWD, GRO, all; box_group: period, month_of_year, doy; twd_fun: mean, max; gro_fun: max, mean; cols: red, blue
- `plot.ZG_output_clim(x, y = NULL, ..., climate_var = NULL, climate_vars = NULL, numeric_vars = NULL, compare = FALSE, temporal = NULL)`
- `plot.daily_output(x, y = NULL, Year = NULL, DOY = NULL, type = c("summary", "amplitude", "minmax_ribbon", "timing", "timing_violin", "lag", "change", "boxplot", "heatmap"), stat = c("amplitude", "Max_diff", "mean", "median", "Max", "Min", "lag_h", "Time_min_h", "Time_max_h"), by = c("month", "month_of_year", "year"), box_style = c("boxplot", "violin", "both"), status_cols = c( growing = "forestgreen", shrinking = "firebrick", stable = "grey60" ), timing_segment_cols = c( "max after min" = "grey65", "max before/equal min" = "black" ), ...)`
  - Variations: type: summary, amplitude, minmax_ribbon, timing, timing_violin, lag, change, boxplot, heatmap; stat: amplitude, Max_diff, mean, median, Max, Min, lag_h, Time_min_h, Time_max_h; by: month, month_of_year, year; box_style: boxplot, violin, both; status_cols: forestgreen, firebrick, grey60; timing_segment_cols: max after min, grey65, max before/equal min, black
- `plot.daily_output_clim(x, y = NULL, ..., climate_var = NULL, climate_vars = NULL, numeric_vars = NULL, compare = FALSE, temporal = NULL)`
- `plot_event_climate_box(event_data, climate_var, group_var = c("Phase", "event_type"), facet_by = c("none", "month", "month_of_year", "year"), Year = NULL, DOY = NULL, geom = c("boxplot", "violin", "both"), add_test = TRUE, test_method = c("auto", "anova", "kruskal", "t.test", "wilcox"), point_alpha = 0.5)`
  - Variations: group_var: Phase, event_type; facet_by: none, month, month_of_year, year; geom: boxplot, violin, both; test_method: auto, anova, kruskal, t.test, wilcox
- `plot_event_climate_relation(event_data, climate_var, response_var, group_var = NULL, Year = NULL, DOY = NULL, add_smooth = TRUE, point_alpha = 0.7)`
- `summarise_window(start_time, end_time)`
- `twd.maxima(df, TreeNum, smoothing=5)`

## 4 Growth modelling and evaluation

- `dm.fit.gompertz(df, CalYear, TreeNum, f_derivative=F, start = list(b=0.5, k=0.005), verbose = FALSE)`
- `dm.growth.evaluate(df, TreeNum = "all", methods = c( "gam", "gompertz", "logistic", "richards", "loess", "spline", "double_gompertz", "double_richards" ), years = "all", year_mode = c("yearly", "pooled"), fit_GRO = TRUE, site_mode = c("NH", "SH", "CS"), custom_veg_season = c(275, 274), growth_fraction = c(0.1, 0.9), min_unique_growth = 10, rate_threshold_fraction = 0.1, peak_separation_min = 10, valley_ratio_max = 0.4, min_relative_peak = 0.05, start_value_gompertz_parameters = list(a = NA_real_, b = NA_real_, k = NA_real_), start_value_richards_parameters = list(a = NA_real_, k = NA_real_, t0 = NA_real_, v = 1), start_value_double_gompertz_parameters = list( a = NA_real_, k = NA_real_, t0 = NA_real_, a2 = NA_real_, k2 = NA_real_, t02 = NA_real_ ), start_value_double_richards_parameters = list( a = NA_real_, k = NA_real_, t0 = NA_real_, v = 1, a2 = NA_real_, k2 = NA_real_, t02 = NA_real_, v2 = 1 ), loess_span = 0.2, spline_df = 10, verbose = TRUE)`
  - Variations: methods: gam, gompertz, logistic, richards, loess, spline, double_gompertz, double_richards; year_mode: yearly, pooled; site_mode: NH, SH, CS; custom_veg_season: 275, 274; growth_fraction: 0.1, 0.9
- `dm.growth.fit(df, TreeNum = "all", method = c("gam", "gompertz", "logistic", "richards", "loess", "spline"), years = "all", year_mode = c("yearly", "pooled"), fit_GRO = TRUE, site_mode = c("NH", "SH", "CS"), custom_veg_season = c(275, 274), growth_fraction = c(0.1, 0.9), min_unique_growth = 10, rate_threshold_fraction = 0.1, fix_a_to_observed_max = FALSE, fixed_a_multiplier = 1, start_value_gompertz_parameters = list(a = NA_real_, b = NA_real_, k = NA_real_), start_value_richards_parameters = list(a = NA_real_, k = NA_real_, t0 = NA_real_, v = 1), loess_span = 0.2, spline_df = 10, verbose = TRUE)`
  - Variations: method: gam, gompertz, logistic, richards, loess, spline; year_mode: yearly, pooled; site_mode: NH, SH, CS; custom_veg_season: 275, 274; growth_fraction: 0.1, 0.9
- `dm.growth.fit.double(df, TreeNum = "all", method = c("gompertz", "richards"), years = "all", year_mode = c("yearly", "pooled"), fit_GRO = TRUE, site_mode = c("NH", "SH", "CS"), custom_veg_season = c(275, 274), growth_fraction = c(0.1, 0.9), min_unique_growth = 10, rate_threshold_fraction = 0.1, peak_separation_min = 10, valley_ratio_max = 0.4, min_relative_peak = 0.05, fallback_to_single = TRUE, fix_a_to_observed_max = FALSE, fixed_a_multiplier = 1, start_value_double_gompertz_parameters = list( a = NA_real_, k = NA_real_, t0 = NA_real_, a2 = NA_real_, k2 = NA_real_, t02 = NA_real_ ), start_value_double_richards_parameters = list( a = NA_real_, k = NA_real_, t0 = NA_real_, v = 1, a2 = NA_real_, k2 = NA_real_, t02 = NA_real_, v2 = 1 ), verbose = TRUE)`
  - Variations: method: gompertz, richards; year_mode: yearly, pooled; site_mode: NH, SH, CS; custom_veg_season: 275, 274; growth_fraction: 0.1, 0.9
- `plot.dm_growth_evaluation(x, metric = c( "rmse", "mae", "bias", "abs_bias", "r2", "correlation", "nrmse", "rss", "aic_approx", "bic_approx" ), type = c("boxplot", "mean", "heatmap"), order_methods = TRUE, decreasing = NULL, show_points = TRUE, show_errorbar = TRUE, heatmap_label = c("series_fit", "series", "fit_id"), na.rm = TRUE, ...)`
  - Variations: metric: rmse, mae, bias, abs_bias, r2, correlation, nrmse, rss, aic_approx, bic_approx; type: boxplot, mean, heatmap; heatmap_label: series_fit, series, fit_id
- `plot.dm_growth_fit(x, type = c("fit", "season", "residuals", "timing", "overlay", "parameters"), series = NULL, fit_id = NULL, facet_by = c("default", "tree", "year", "none"), ncol = NULL, normalize = FALSE, x_axis = c("default", "season_day", "doy", "date"), observed_source = c("processed", "original_daily"), show_observed = TRUE, show_fitted = TRUE, show_timing = TRUE, point_alpha = 0.7, line_width = 0.8, legend_position = "right", ...)`
  - Variations: type: fit, season, residuals, timing, overlay, parameters; facet_by: default, tree, year, none; x_axis: default, season_day, doy, date; observed_source: processed, original_daily
- `print.dm_growth_fit(x, ...)`
- `print.summary.dm_growth_fit(x, ...)`
- `summary.dm_growth_fit(object, ...)`

## 5 Climate integration and TWD response

- `clim.twd(df, Clim, dailyValue = "max", thresholdClim = "<10", thresholdDays = ">5", showPlot = TRUE)`
- `clim.twd.stats(x, tree_info = NULL, response = c("adverse_change", "normal_change", "full_period_change", "continuous_full_period_change"), group_by = c("tree", "species", "site", "species_site"), center = c("mean", "median"), conf_level = 0.95, months = NULL, years = NULL, doy_window = NULL, year_window = NULL, include_tree_series = TRUE)`
  - Variations: response: adverse_change, normal_change, full_period_change, continuous_full_period_change; group_by: tree, species, site, species_site; center: mean, median
- `clim.twd.test(x, tree_info = NULL, parameter = c( "lag_to_below_zero", "lag_to_max_adverse_decline", "lag_to_return_zero", "max_adverse_decline_value", "change_end_adverse", "change_end_full_period", "continuous_end_full_period" ), compare_by = c("tree", "species", "site", "species_site"), within = c("all", "year", "ID"), test_method = c("auto", "t_test", "welch_t", "wilcox", "anova", "kruskal"), ids = NULL, years = NULL, months = NULL, doy_window = NULL, year_window = NULL, pairwise = TRUE, p_adjust_method = "BH", min_n_per_group = 2)`
  - Variations: parameter: lag_to_below_zero, lag_to_max_adverse_decline, lag_to_return_zero, max_adverse_decline_value, change_end_adverse, change_end_full_period, continuous_end_full_period; compare_by: tree, species, site, species_site; within: all, year, ID; test_method: auto, t_test, welch_t, wilcox, anova, kruskal
- `dm_add_climate(x, clim, scale = c("auto", "daily", "phase", "subdaily"), mean_vars = NULL, min_vars = NULL, max_vars = NULL, sum_vars = NULL, median_vars = NULL, lag_vars = NULL, lagmean_vars = NULL, lagsum_vars = NULL, lag_days = c(1, 3, 7), sub_mean_vars = NULL, sub_sum_vars = NULL, sub_lag_vars = NULL, roll_hours = c(3, 6, 24), lag_hours = c(1, 3, 6, 24), suffix = "_phase")`
  - Variations: scale: auto, daily, phase, subdaily; lag_days: 1, 3, 7; roll_hours: 3, 6, 24; lag_hours: 1, 3, 6, 24
- `dm_daily_clim(clim_df, mean_vars = NULL, min_vars = NULL, max_vars = NULL, sum_vars = NULL, median_vars = NULL, lag_vars = NULL, lagmean_vars = NULL, lagsum_vars = NULL, lag_days = c(1, 3, 7))`
  - Variations: lag_days: 1, 3, 7
- `dm_subdaily_clim(clim_df, mean_vars = NULL, sum_vars = NULL, lag_vars = NULL, roll_hours = c(3, 6, 24), lag_hours = c(1, 3, 6, 24))`
  - Variations: roll_hours: 3, 6, 24; lag_hours: 1, 3, 6, 24
- `plot.clim_twd_stats(x, y = NULL, type = c("trajectory", "id_metric"), ids = NULL, groups = NULL, band = c("none", "sd", "limit95", "both"), metric = c("lag_to_below_zero", "lag_to_max_adverse_decline", "lag_to_return_zero", "max_adverse_decline_value", "change_end_adverse", "change_end_full_period", "continuous_end_full_period"), facet_by = c("IDs", "group", "none"), legend_position = "bottom", main = NULL, ...)`
  - Variations: type: trajectory, id_metric; band: none, sd, limit95, both; metric: lag_to_below_zero, lag_to_max_adverse_decline, lag_to_return_zero, max_adverse_decline_value, change_end_adverse, change_end_full_period, continuous_end_full_period; facet_by: IDs, group, none
- `plot.clim_twd_test(x, y = NULL, show_points = TRUE, facet = TRUE, legend_position = "none", main = NULL, ...)`
- `print.summary.clim_twd_stats(x, ...)`
- `print.summary.clim_twd_test(x, ...)`
- `read.climate(x, time_col = NULL, vars = NULL, sep = NULL, dec = ".", header = TRUE, sheet = 1, tz = "UTC", drop_duplicate_time = TRUE, min_time_success = 0.6, verbose = TRUE)`
- `summary.clim_twd_stats(object, ...)`
- `summary.clim_twd_test(object, ...)`

## 6 Event, correlation and wavelet analyses

- `dm_epoch_extract(events, clim, vars = "all", lag_before = 24, lag_after = 24, step = 1, unit = c("hours", "days", "mins"), agg_fun = "mean", var_funs = NULL, Year = NULL, DOY = NULL, restrict_null_to_window = TRUE)`
  - Variations: unit: hours, days, mins
- `dm_epoch_test(x, statistic = c("mean", "median"), null = c("same_doy_window", "same_month", "random_time"), n_iter = 1000, doy_window = 15, match_hour = TRUE, match_minute = TRUE, conf_level = 0.95, seed = NULL)`
  - Variations: statistic: mean, median; null: same_doy_window, same_month, random_time
- `dm_event_times(x, event = "all", phase = NULL, min_duration = NULL, min_magnitude = NULL, min_max_twd = NULL, remove_na_times = TRUE)`
- `dm_wavelet(x, TreeNum = "all", source = c("auto", "raw", "detrended", "first_diff"), detrended_col = c("detrended_data"), na_action = c("interpolate", "fail"), loess_span = 0.75, dj = 1 / 20, lowerPeriod = NULL, upperPeriod = NULL, make_pval = TRUE, n_sim = 10, verbose = TRUE)`
  - Variations: source: auto, raw, detrended, first_diff; detrended_col: detrended_data; na_action: interpolate, fail
- `dm_wavelet_coherence(dm, clim, TreeNum = "all", clim_vars = "all", source = c("auto", "raw", "detrended", "first_diff"), detrended_col = c("detrended_data"), dm_fun = c("mean", "max", "min", "sum"), clim_funs = "mean", na_action = c("interpolate", "fail"), loess_span = 0, dj = 1 / 20, lowerPeriod = NULL, upperPeriod = NULL, window.type.t = 1, window.type.s = 1, window.size.t = 5, window.size.s = 1 / 4, make.pval = TRUE, make_pval = NULL, method = "white.noise", n.sim = 10, n_sim = NULL, verbose = TRUE)`
  - Variations: source: auto, raw, detrended, first_diff; detrended_col: detrended_data; dm_fun: mean, max, min, sum; na_action: interpolate, fail
- `dm_wavelet_reconstruct(x, series = NULL, mode = c("extract", "remove"), period_hours = NULL, lower_hours = NULL, upper_hours = NULL, lvl = 0, only_sig = TRUE, siglvl = 0.05, only_coi = FALSE, only_ridge = FALSE, rescale = FALSE, verbose = TRUE)`
  - Variations: mode: extract, remove
- `dmw_complete_regular(dat, dt_sec)`
- `dmw_fill_na(z)`
- `dmw_infer_dt(time_vec)`
- `dmw_parse_time(tt)`
- `dmw_period_to_hours(period, time_unit)`
- `dmw_period_to_hours(period, time_unit)`
- `dmw_select_cols(dat, TreeNum, meta_cols = character(0))`
- `dmwc_fill_na(z)`
- `dmwc_fun_match(fun_name)`
- `dmwc_infer_dt(time_vec)`
- `dmwc_parse_time(tt)`
- `dmwc_period_to_hours(period, time_unit)`
- `dmwc_resample_regular(dat, target_sec, fun_map)`
- `dmwc_select_cols(dat, selector, exclude = character(0))`
- `dwr_hours_to_native(hours, time_unit)`
- `dwr_native_to_hours(native, time_unit)`
- `mov.cor.dm(df, Clim, TreeNum, win_size, cor_method = c("pearson", "kendall", "spearman"), boot = FALSE, R = 1000, boot.ci = 0.05, set_seed = 1, dm_stat = c("mean", "min", "max", "median", "amplitude", "change"), clim_vars = NULL, lag_days = 0, accum_days = 1, clim_fun = "raw", min_complete = NULL, p_adjust_method = "BH")`
  - Variations: cor_method: pearson, kendall, spearman; dm_stat: mean, min, max, median, amplitude, change
- `plot.dm_epoch(x, y = NULL, type = c("composite", "heatmap", "difference"), variables = NULL, facet = TRUE, show_ci = TRUE, legend_position = "right", ...)`
  - Variations: type: composite, heatmap, difference
- `plot.dm_wavelet(x, y = NULL, series = NULL, type = c("power", "average", "series"), facet = TRUE, log_period = TRUE, log_power = TRUE, clip_quantile = c(0.01, 0.99), show_sig = TRUE, show_coi = TRUE, coi_fill = "white", coi_alpha = 0.45, siglvl = 0.05, sig_color = "black", sig_size = 0.4, main = NULL, ...)`
  - Variations: type: power, average, series; clip_quantile: 0.01, 0.99
- `plot.dm_wavelet_coherence(x, y = NULL, pair = NULL, type = c("coherence", "cross_power", "average_coherence", "average_cross_power", "phase", "series"), facet = TRUE, log_period = TRUE, log_power = TRUE, clip_quantile = c(0.01, 0.99), show_sig = TRUE, show_coi = TRUE, siglvl = 0.05, sig_color = "black", sig_size = 0.4, coi_fill = "white", coi_alpha = 0.45, main = NULL, ...)`
  - Variations: type: coherence, cross_power, average_coherence, average_cross_power, phase, series; clip_quantile: 0.01, 0.99
- `plot.dm_wavelet_reconstruct(x, y = NULL, series = NULL, type = c("compare", "reconstructed", "difference", "filtered"), facet = TRUE, legend_position = "right", line_width = 0.8, alpha = 0.7, main = NULL, ...)`
  - Variations: type: compare, reconstructed, difference, filtered
- `plot.mov.cor(x, y = NULL, ...)`
- `plot.mov.cor.boot(x, y = NULL, ...)`
- `plot.mov_cor_dm(x, y = NULL, sig.only = TRUE, ci = 0.95, clim_vars = "all", type = c("heatmap", "line", "facet", "peak", "compare"), x_axis = c("time", "doy"), use_adjusted = TRUE, show_na = TRUE, show_ci = FALSE, sig_mode = c("outline", "point", "filter", "none"), annotate_peak = FALSE, show_window_label = TRUE, compare_with = NULL, compare_labels = NULL, low_col = "red", mid_col = "white", high_col = "blue", na_col = "grey79", line_size = 0.5, point_size = 1.8, alpha_sig = 0.9, ...)`
  - Variations: type: heatmap, line, facet, peak, compare; x_axis: time, doy; sig_mode: outline, point, filter, none
- `plot.summary_mov_cor_dm(x, y = NULL, type = c("peak_corr", "prop_significant", "peak_time"), x_axis = c("time", "doy"), low_col = "red", mid_col = "white", high_col = "blue", show_window_label = TRUE, ...)`
  - Variations: type: peak_corr, prop_significant, peak_time; x_axis: time, doy
- `plot_mov.cor(mov.cor.output, ...)`
- `print.mov_cor_dm(x, ...)`
- `print.summary.dm_epoch(x, ...)`
- `print.summary.dm_wavelet(x, ...)`
- `print.summary.dm_wavelet_reconstruct(x, digits = 4, ...)`
- `print.summary_mov_cor_dm(x, ...)`
- `summary.dm_epoch(object, ...)`
- `summary.dm_wavelet(object, top_n = 3, ...)`
- `summary.dm_wavelet_reconstruct(object, ...)`
- `summary.mov_cor_dm(object, absolute = TRUE, top_n = 5, ...)`
