source("00_setup.R")

workshop_data <- load_workshop_data()
dm <- workshop_data$dm
clim <- workshop_data$clim

print(workshop_data$source)
print(dplyr::glimpse(dm))
print(dplyr::glimpse(clim))
