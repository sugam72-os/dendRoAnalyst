source("00_setup.R")

workshop_data <- load_workshop_data()
dm <- workshop_data$dm
clim <- workshop_data$clim

# Select trees once for the examples.
tree_set <- names(dm)[names(dm) != "TIME"]

# 1. Resolution and resampling
reso_dm(dm$TIME)
dm_hourly <- dendro.resample(dm, by = "1 hour", value = "mean", method = "auto")

# 2. Gap interpolation
interp <- dm.na.interpolation(dm_hourly, resolution = "hourly", method = "spline", assess = FALSE)
dm_filled <- interp$data

# 3. Daily summaries and phases
daily <- daily.data(dm_filled, TreeNum = tree_set)
zg <- phase.zg(dm_filled, TreeNum = tree_set, smoothing = 5, beta = 0.1)
sc <- phase.sc(dm_filled, TreeNum = tree_set, smoothing = 5)

# 4. Climate summaries and joining
daily_clim <- dm_daily_clim(clim, mean_vars = c("temp", "VPD", "RH"), sum_vars = "prec")
daily_clim_joined <- dm_join_daily_clim(daily, daily_clim)

# 5. Growth models
fit_gam <- dm.growth.fit(daily, TreeNum = "all", method = "gam")
fit_gom <- dm.growth.fit(daily, TreeNum = "all", method = "gompertz")
eval <- dm.growth.evaluate(daily, TreeNum = "all", methods = c("gam", "gompertz", "loess", "spline"))

# 6. Save example objects
saveRDS(list(
  daily = daily,
  zg = zg,
  sc = sc,
  fit_gam = fit_gam,
  fit_gom = fit_gom,
  eval = eval
), "outputs/saved_objects/workshop_results.rds")
