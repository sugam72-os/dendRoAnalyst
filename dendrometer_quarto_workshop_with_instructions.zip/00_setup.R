# 00_setup.R ------------------------------------------------------------
# Load packages, source workshop functions, define helpers, and load data.

required_packages <- c(
  "tidyverse", "lubridate", "zoo", "forecast", "WaveletComp", "here",
  "conflicted", "readxl", "readr", "minpack.lm", "mgcv", "changepoint",
  "boot", "pspline", "signal"
)

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  stop(
    "Missing packages: ", paste(missing_packages, collapse = ", "),
    "\nRun install.R first, or install the missing packages manually.",
    call. = FALSE
  )
}

library(tidyverse)
library(lubridate)
library(zoo)
library(forecast)
library(WaveletComp)
library(here)
library(conflicted)

conflict_prefer("filter", "dplyr", quiet = TRUE)
conflict_prefer("lag", "dplyr", quiet = TRUE)

source(here::here("R", "helpers", "source_workshop_functions.R"))
source_workshop_functions(verbose = FALSE)

# Helper: create output directories -------------------------------------
create_output_dirs <- function() {
  dirs <- c(
    "outputs/figures",
    "outputs/tables",
    "outputs/saved_objects",
    "data/processed"
  )

  invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))
}

# Helper: simulated fallback data ---------------------------------------
# This is only a teaching fallback. Prefer real package datasets or your own
# conference/workshop dataset.
make_simulated_workshop_data <- function(
  n_days = 40,
  resolution_min = 60,
  tz = "UTC"
) {
  time <- seq.POSIXt(
    from = as.POSIXct("2023-05-01 00:00:00", tz = tz),
    by = paste(resolution_min, "mins"),
    length.out = n_days * 24 * 60 / resolution_min
  )

  hour <- lubridate::hour(time)
  set.seed(42)

  growth <- seq(0, 250, length.out = length(time))
  daily_cycle <- sin(2 * pi * hour / 24) * 12
  noise <- rnorm(length(time), sd = 2)

  dm <- tibble::tibble(
    TIME = time,
    T1 = 1000 + growth + daily_cycle + noise,
    T2 = 980 + growth * 0.8 + daily_cycle * 0.8 + rnorm(length(time), sd = 2.5),
    T3 = 1030 + growth * 1.1 + daily_cycle * 1.2 + rnorm(length(time), sd = 2)
  )

  temp <- 16 + 8 * sin(2 * pi * hour / 24) + rnorm(length(time), sd = 1)
  rh <- pmin(100, pmax(30, 80 - 20 * sin(2 * pi * hour / 24) + rnorm(length(time), sd = 5)))
  vpd <- pmax(0, (100 - rh) / 100 * exp(temp / 25))
  prec <- ifelse(runif(length(time)) < 0.04, rexp(length(time), rate = 2), 0)

  clim <- tibble::tibble(
    TIME = time,
    temp = temp,
    RH = rh,
    VPD = vpd,
    prec = prec
  )

  list(dm = dm, clim = clim)
}

# Helper: first existing file -------------------------------------------
first_existing_file <- function(paths) {
  existing <- paths[file.exists(paths)]
  if (length(existing) == 0) return(NA_character_)
  existing[1]
}

# Helper: candidate dendrometer files -----------------------------------
get_dendrometer_candidates <- function(data_dir = "data/raw") {
  file.path(
    data_dir,
    c(
      "dm.csv", "dm.tsv", "dm.txt", "dm.xlsx", "dm.xls",
      "dendrometer.csv", "dendrometer.tsv", "dendrometer.txt", "dendrometer.xlsx", "dendrometer.xls",
      "dendrometer_data.csv", "dendrometer_data.tsv", "dendrometer_data.txt", "dendrometer_data.xlsx", "dendrometer_data.xls",
      "nepa17.csv", "nepa17.tsv", "nepa17.txt", "nepa17.xlsx", "nepa17.xls"
    )
  )
}

# Helper: candidate climate files ---------------------------------------
get_climate_candidates <- function(data_dir = "data/raw") {
  file.path(
    data_dir,
    c(
      "clim.csv", "clim.tsv", "clim.txt", "clim.xlsx", "clim.xls",
      "climate.csv", "climate.tsv", "climate.txt", "climate.xlsx", "climate.xls",
      "climate_data.csv", "climate_data.tsv", "climate_data.txt", "climate_data.xlsx", "climate_data.xls",
      "ktm_clim_hourly.csv", "ktm_clim_hourly.tsv", "ktm_clim_hourly.txt", "ktm_clim_hourly.xlsx", "ktm_clim_hourly.xls"
    )
  )
}

# Helper: read dendrometer data -----------------------------------------
read_workshop_dendrometer <- function(path, ...) {
  if (!file.exists(path)) {
    stop("Dendrometer file not found: ", path, call. = FALSE)
  }

  message("Reading dendrometer data using read.dendrometer(): ", path)
  dm <- read.dendrometer(path, ...)

  if (inherits(dm, "data.frame")) {
    dm <- tibble::as_tibble(dm)
  }

  dm
}

# Helper: read climate data ---------------------------------------------
read_workshop_climate <- function(path, ...) {
  if (!file.exists(path)) {
    stop("Climate file not found: ", path, call. = FALSE)
  }

  message("Reading climate data using read.climate(): ", path)
  clim <- read.climate(path, ...)

  if (inherits(clim, "data.frame")) {
    clim <- tibble::as_tibble(clim)
  }

  clim
}

# Helper: load package example data if available ------------------------
load_package_example_data <- function() {
  if (!requireNamespace("dendRoAnalyst", quietly = TRUE)) {
    return(NULL)
  }

  package_data <- try(
    utils::data(package = "dendRoAnalyst")$results[, "Item"],
    silent = TRUE
  )

  if (inherits(package_data, "try-error")) {
    return(NULL)
  }

  if (all(c("nepa17", "ktm_clim_hourly") %in% package_data)) {
    env <- new.env(parent = emptyenv())
    data("nepa17", package = "dendRoAnalyst", envir = env)
    data("ktm_clim_hourly", package = "dendRoAnalyst", envir = env)

    return(list(dm = env$nepa17, clim = env$ktm_clim_hourly))
  }

  NULL
}

# Helper: load workshop data --------------------------------------------
# Loading priority:
# 1. Explicit files supplied by dm_file and clim_file
# 2. Automatically detected files from data/raw
# 3. Package example datasets: nepa17 and ktm_clim_hourly, if installed
# 4. Simulated teaching data
load_workshop_data <- function(
  prefer_data_folder = TRUE,
  data_dir = "data/raw",
  dm_file = NULL,
  clim_file = NULL,
  prefer_package_data = TRUE,
  use_simulated_fallback = TRUE,
  tz = "UTC",
  dm_args = list(),
  clim_args = list()
) {
  create_output_dirs()

  if (!is.null(dm_file) || !is.null(clim_file)) {
    if (is.null(dm_file)) {
      stop("You provided clim_file but not dm_file. Please provide both files.", call. = FALSE)
    }

    if (is.null(clim_file)) {
      stop("You provided dm_file but not clim_file. Please provide both files.", call. = FALSE)
    }

    message("Loading workshop data from explicit files:")
    message("  Dendrometer: ", dm_file)
    message("  Climate:     ", clim_file)

    dm <- do.call(read_workshop_dendrometer, c(list(path = dm_file, tz = tz), dm_args))
    clim <- do.call(read_workshop_climate, c(list(path = clim_file, tz = tz), clim_args))

    return(list(dm = dm, clim = clim, source = "explicit_files", dm_file = dm_file, clim_file = clim_file))
  }

  if (prefer_data_folder && dir.exists(data_dir)) {
    dm_path <- first_existing_file(get_dendrometer_candidates(data_dir))
    clim_path <- first_existing_file(get_climate_candidates(data_dir))

    if (!is.na(dm_path) && !is.na(clim_path)) {
      message("Loaded workshop data from data folder:")
      message("  Dendrometer: ", dm_path)
      message("  Climate:     ", clim_path)

      dm <- do.call(read_workshop_dendrometer, c(list(path = dm_path, tz = tz), dm_args))
      clim <- do.call(read_workshop_climate, c(list(path = clim_path, tz = tz), clim_args))

      return(list(dm = dm, clim = clim, source = "data_folder", dm_file = dm_path, clim_file = clim_path))
    }

    if (is.na(dm_path)) message("No dendrometer file found in: ", data_dir)
    if (is.na(clim_path)) message("No climate file found in: ", data_dir)
  }

  if (prefer_package_data) {
    package_data <- load_package_example_data()

    if (!is.null(package_data)) {
      message("Loaded package datasets: nepa17 and ktm_clim_hourly")
      return(list(
        dm = package_data$dm,
        clim = package_data$clim,
        source = "package_data",
        dm_file = NA_character_,
        clim_file = NA_character_
      ))
    }
  }

  if (use_simulated_fallback) {
    message("No suitable data-folder or package datasets found. Using simulated teaching data.")
    sim_data <- make_simulated_workshop_data(tz = tz)

    return(list(
      dm = sim_data$dm,
      clim = sim_data$clim,
      source = "simulated_data",
      dm_file = NA_character_,
      clim_file = NA_character_
    ))
  }

  stop(
    "No workshop data could be loaded. Provide dm_file and clim_file, ",
    "or place suitable files in data/raw/.",
    call. = FALSE
  )
}

# Helper: save plots consistently ---------------------------------------
save_workshop_plot <- function(plot, filename, width = 8, height = 5, dpi = 300) {
  dir.create("outputs/figures", recursive = TRUE, showWarnings = FALSE)

  ggplot2::ggsave(
    filename = file.path("outputs/figures", filename),
    plot = plot,
    width = width,
    height = height,
    dpi = dpi
  )
}

message("Setup complete. Use: workshop_data <- load_workshop_data()")
