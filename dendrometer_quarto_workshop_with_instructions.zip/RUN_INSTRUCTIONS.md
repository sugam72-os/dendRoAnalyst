# How to run the Dendrometer Quarto Workshop Project

These instructions assume you have downloaded and unzipped `dendrometer_quarto_workshop.zip`.

## 1. Software needed

Install these before running the workshop:

- R, preferably version 4.3 or newer
- RStudio Desktop
- Quarto CLI

In RStudio, check that Quarto is available by running:

```r
quarto::quarto_version()
```

If this gives an error, install Quarto first, then restart RStudio.

## 2. Open the project

Unzip the workshop folder, then open:

```text
dendrometer-workshop.Rproj
```

Opening the `.Rproj` file is important because it sets the working directory correctly.

## 3. Install required R packages

Run this once in the R console:

```r
source("install.R")
```

This installs the main packages used by the workshop, including `tidyverse`, `lubridate`, `zoo`, `forecast`, `WaveletComp`, `quarto`, `knitr`, and `rmarkdown`.

The package `dendRoAnalyst` is treated as optional because the workshop also includes local copies of the uploaded functions under `R/functions/`.

## 4. Add your data

Place your raw dendrometer and climate files in:

```text
data/raw/
```

Recommended automatic file names are:

```text
data/raw/dendrometer.csv
data/raw/climate.csv
```

Other accepted names include:

```text
data/raw/dm.csv
data/raw/dm.txt
data/raw/dendrometer.txt

data/raw/clim.csv
data/raw/clim.txt
data/raw/climate.txt
```

Dendrometer data are read with:

```r
read.dendrometer()
```

Climate data are read with:

```r
read.climate()
```

## 5. Load setup and data

Run:

```r
source("00_setup.R")

workshop_data <- load_workshop_data()

dm <- workshop_data$dm
clim <- workshop_data$clim
```

The loader tries this order:

1. Explicit files supplied with `dm_file` and `clim_file`
2. Files detected automatically in `data/raw/`
3. Package example datasets, if available
4. Simulated teaching data as fallback

## 6. Load explicit data files instead

If your files have different names, use explicit paths:

```r
source("00_setup.R")

workshop_data <- load_workshop_data(
  dm_file = "data/raw/my_dendrometer_file.csv",
  clim_file = "data/raw/my_climate_file.csv"
)

dm <- workshop_data$dm
clim <- workshop_data$clim
```

## 7. Render the Quarto workshop book

From the R console:

```r
quarto::quarto_render(".")
```

Or from the terminal inside the project folder:

```bash
quarto render
```

The rendered HTML book will be created in:

```text
_site/
```

Open this file in a browser:

```text
_site/index.html
```

## 8. Run lessons interactively

The Quarto project is configured with:

```yaml
execute:
  eval: false
```

This means the book can render even before real data are added. During the workshop, open each `.qmd` file in RStudio and run the R chunks interactively.

Start with:

```text
index.qmd
modules/01_import_resample_clean.qmd
modules/02_standardize_detrend.qmd
modules/03_daily_phase_analysis.qmd
modules/04_growth_modelling.qmd
modules/05_climate_integration.qmd
modules/06_events_correlations_wavelets.qmd
modules/07_function_catalogue.qmd
exercises/exercises.qmd
```

## 9. Run the example scripts

You can also run the scripts directly:

```r
source("scripts/01_load_data.R")
source("scripts/02_full_workflow_template.R")
```

## 10. Outputs

Generated results are saved in:

```text
outputs/figures/
outputs/tables/
outputs/saved_objects/
data/processed/
```

## 11. Troubleshooting

### Problem: `read.dendrometer()` or `read.climate()` not found

Run:

```r
source("00_setup.R")
```

This sources the local function files in `R/functions/`.

### Problem: Quarto render fails

First check Quarto:

```r
quarto::quarto_version()
```

Then render again:

```r
quarto::quarto_render(".")
```

### Problem: data not found

Check that your files are inside `data/raw/`, or use explicit paths:

```r
load_workshop_data(
  dm_file = "data/raw/your_dendrometer_file.csv",
  clim_file = "data/raw/your_climate_file.csv"
)
```

### Problem: package installation fails

Install missing packages one by one, for example:

```r
install.packages("tidyverse")
install.packages("lubridate")
install.packages("zoo")
install.packages("forecast")
install.packages("WaveletComp")
```

Then rerun:

```r
source("install.R")
```

## 12. Recommended first run

For a clean first test, run these commands:

```r
source("install.R")
source("00_setup.R")

workshop_data <- load_workshop_data()

dm <- workshop_data$dm
clim <- workshop_data$clim

str(dm)
str(clim)

quarto::quarto_render(".")
```

