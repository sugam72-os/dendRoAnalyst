# =========================================================
# Internal helpers
# =========================================================

.dm_parse_time_candidate <- function(x, tz = "UTC") {
  if (inherits(x, "POSIXct")) return(as.POSIXct(x, tz = tz))
  if (inherits(x, "Date")) return(as.POSIXct(x, tz = tz))

  if (is.factor(x)) x <- as.character(x)

  # numeric: try Excel serial first, then Unix seconds, then Unix milliseconds
  if (is.numeric(x)) {
    out <- rep(as.POSIXct(NA, origin = "1970-01-01", tz = tz), length(x))
    ok <- is.finite(x)

    if (any(ok)) {
      xr <- range(x[ok], na.rm = TRUE)

      # Excel serial dates (roughly 1954-2149)
      if (xr[1] > 20000 && xr[2] < 100000) {
        out[ok] <- as.POSIXct(x[ok] * 86400, origin = "1899-12-30", tz = tz)
        return(out)
      }

      # Unix milliseconds
      if (xr[1] > 1e12 && xr[2] < 5e13) {
        out[ok] <- as.POSIXct(x[ok] / 1000, origin = "1970-01-01", tz = tz)
        return(out)
      }

      # Unix seconds
      if (xr[1] > 1e8 && xr[2] < 5e9) {
        out[ok] <- as.POSIXct(x[ok], origin = "1970-01-01", tz = tz)
        return(out)
      }
    }

    return(out)
  }

  x <- trimws(as.character(x))
  x[x == ""] <- NA_character_

  # try multiple common date-time/date formats
  parsed <- suppressWarnings(
    lubridate::parse_date_time(
      x,
      orders = c(
        "ymd HMS", "ymd HM", "ymd",
        "Ymd HMS", "Ymd HM", "Ymd",
        "dmy HMS", "dmy HM", "dmy",
        "mdy HMS", "mdy HM", "mdy"
      ),
      tz = tz,
      quiet = TRUE
    )
  )

  as.POSIXct(parsed, tz = tz)
}

.dm_auto_find_time_col <- function(dat, tz = "UTC", min_success = 0.6) {
  nms <- names(dat)
  scores <- rep(NA_real_, length(nms))
  parsed_list <- vector("list", length(nms))

  for (i in seq_along(nms)) {
    v <- dat[[i]]
    parsed <- .dm_parse_time_candidate(v, tz = tz)
    parsed_list[[i]] <- parsed

    valid_input <- if (is.character(v) || is.factor(v)) {
      !is.na(v) & trimws(as.character(v)) != ""
    } else {
      !is.na(v)
    }

    denom <- sum(valid_input)
    success <- if (denom == 0) 0 else sum(!is.na(parsed) & valid_input) / denom

    # slight preference to names that look like time/date columns
    name_bonus <- if (grepl("time|date|datetime|timestamp", nms[i], ignore.case = TRUE)) 0.05 else 0
    scores[i] <- success + name_bonus
  }

  best <- which.max(scores)
  best_success <- if (length(best) == 0) 0 else scores[best]

  if (length(best) == 0 || best_success < min_success) {
    stop(
      "Could not detect a valid climate time column automatically. ",
      "Please provide 'time_col' explicitly. Accepted formats are POSIXct, Date, ",
      "or character timestamps such as 'yyyy-mm-dd HH:MM:SS'."
    )
  }

  list(
    time_col = nms[best],
    parsed_time = parsed_list[[best]]
  )
}

.dm_maybe_numeric <- function(x, dec = ".") {
  if (is.numeric(x)) return(x)
  if (inherits(x, "POSIXct") || inherits(x, "Date")) return(x)

  z <- trimws(as.character(x))
  z[z == ""] <- NA_character_

  if (!identical(dec, ".")) {
    z <- gsub(dec, ".", z, fixed = TRUE)
  }

  num <- suppressWarnings(as.numeric(z))

  ok_in <- sum(!is.na(z))
  ok_out <- sum(!is.na(num))

  # only coerce if most non-missing values can be converted
  if (ok_in > 0 && ok_out / ok_in >= 0.8) {
    return(num)
  }

  x
}

.dm_resolution_hours <- function(time) {
  d <- diff(as.numeric(time)) / 3600
  d <- d[is.finite(d) & d > 0]
  if (length(d) == 0) return(NA_real_)
  stats::median(d)
}

.dm_is_irregular <- function(time) {
  d <- diff(as.numeric(time)) / 60
  d <- d[is.finite(d) & d > 0]
  if (length(d) <= 1) return(FALSE)
  length(unique(round(d, 6))) > 1
}

.dm_safe_agg <- function(x, FUN) {
  if (length(x) == 0 || all(is.na(x))) return(NA_real_)
  FUN(x, na.rm = TRUE)
}

.dm_roll_right <- function(x, n, FUN) {
  n <- as.integer(n)
  out <- rep(NA_real_, length(x))

  if (length(x) == 0 || n <= 0) return(out)
  if (n > length(x)) return(out)

  for (i in seq_along(x)) {
    if (i >= n) {
      out[i] <- .dm_safe_agg(x[(i - n + 1):i], FUN)
    }
  }
  out
}

.dm_lag_vec <- function(x, n) {
  n <- as.integer(n)
  if (n <= 0) return(x)
  if (n >= length(x)) return(rep(NA, length(x)))
  c(rep(NA, n), x[seq_len(length(x) - n)])
}

.dm_prepare_climate <- function(clim_input, verbose = FALSE) {
  if (inherits(clim_input, "dm_clim")) {
    out <- tibble::as_tibble(clim_input)
    out$TIME <- as.POSIXct(out$TIME)
    out <- out[order(out$TIME), , drop = FALSE]
    return(out)
  }
  read.climate(clim_input, verbose = verbose)
}



#' @title Read and standardize climate data for dendrometer analyses
#'
#' @description
#' Reads and standardizes climate data so they can be used by
#' \code{dm_daily_clim()}, \code{dm_subdaily_clim()},
#' \code{dm_join_daily_clim()}, \code{dm_join_phase_clim()}, and
#' \code{dm_join_subdaily_clim()}.
#'
#' The function accepts a data frame or a file path. It can read:
#' \itemize{
#'   \item csv files
#'   \item tabular text files (txt, tsv, tab, dat)
#'   \item Excel files (xls, xlsx)
#' }
#'
#' It automatically detects the time column if \code{time_col = NULL}, converts
#' it to a standardized \code{POSIXct} column named \code{TIME}, places that
#' column in the first position, sorts the data by time, optionally removes
#' duplicate timestamps, and keeps selected climate variables if requested.
#'
#' @details
#' The time column can be located in the first column or in any named column.
#' Accepted time formats are:
#' \itemize{
#'   \item \code{POSIXct}
#'   \item \code{Date}
#'   \item character timestamp in full format \code{"yyyy-mm-dd HH:MM:SS"}
#'   \item character date in format \code{"yyyy-mm-dd"}
#'   \item common alternatives such as \code{"dd.mm.yyyy HH:MM:SS"} or \code{"mm/dd/yyyy HH:MM"}
#'   \item numeric Excel serial dates
#'   \item numeric Unix timestamps in seconds or milliseconds
#' }
#'
#' For subdaily analyses, full timestamps such as
#' \code{"yyyy-mm-dd HH:MM:SS"} or \code{POSIXct} are strongly recommended.
#'
#' @param x Either a data frame containing climate data, or a character string
#'   giving the path to a csv, text/table, or Excel file.
#' @param time_col Optional character string giving the name of the time column.
#'   If \code{NULL}, the function tries to detect the time column automatically.
#' @param vars Optional character vector of climate variables to keep. If
#'   \code{NULL}, all remaining columns are kept.
#' @param sep Field separator for text files. If \code{NULL}, it is inferred from
#'   the file extension: \code{","} for csv, \code{"\t"} for tsv/tab, and
#'   whitespace for txt/dat.
#' @param dec Decimal separator for text files, usually \code{"."} or \code{","}.
#' @param header Logical. Passed to \code{utils::read.table()} when reading text files.
#' @param sheet Sheet index or sheet name for Excel files.
#' @param tz Time zone used when parsing character timestamps.
#' @param drop_duplicate_time Logical. If \code{TRUE}, duplicated timestamps are
#'   removed, keeping the first occurrence.
#' @param min_time_success Minimum successful parsing rate required when detecting
#'   the time column automatically.
#' @param verbose Logical. If \code{TRUE}, a short summary is printed.
#'
#' @return
#' A tibble with a standardized \code{TIME} column in the first position and
#' climate variables in the remaining columns. The returned object has class
#' \code{"dm_clim"}.
#'
#' @examples
#' \donttest{
#' # From a data frame
#' ####clim_std <- read.climate(clim_df, time_col = "TIME", verbose = FALSE)
#'
#' # Keep only selected variables
#' #clim_std2 <- read.climate(
#' #  clim_df,
#' #  time_col = "TIME",
#' #  vars = c("Tair", "RH", "VPD", "P", "SWC", "Rad"),
#' #  verbose = FALSE
#' #)
#' }
#'
#' @importFrom tibble as_tibble
#' @importFrom dplyr select all_of
#' @importFrom lubridate parse_date_time
#' @importFrom utils read.table
#' @importFrom readxl read_excel
#' @export
read.climate <- function(x,
                         time_col = NULL,
                         vars = NULL,
                         sep = NULL,
                         dec = ".",
                         header = TRUE,
                         sheet = 1,
                         tz = "UTC",
                         drop_duplicate_time = TRUE,
                         min_time_success = 0.6,
                         verbose = TRUE) {

  # read input
  dat <- TIME <- NULL

  if (is.data.frame(x)) {
    dat <- tibble::as_tibble(x)
  } else if (is.character(x) && length(x) == 1 && file.exists(x)) {
    ext <- tolower(tools::file_ext(x))

    if (ext %in% c("csv", "txt", "tsv", "tab", "dat")) {
      if (is.null(sep)) {
        sep <- switch(
          ext,
          csv = ",",
          tsv = "\t",
          tab = "\t",
          txt = "",
          dat = "",
          ","
        )
      }

      dat <- utils::read.table(
        file = x,
        sep = sep,
        dec = dec,
        header = header,
        stringsAsFactors = FALSE,
        check.names = FALSE,
        fill = TRUE,
        comment.char = "",
        quote = "\"'"
      )
      dat <- tibble::as_tibble(dat)

    } else if (ext %in% c("xls", "xlsx")) {
      dat <- readxl::read_excel(path = x, sheet = sheet)
      dat <- tibble::as_tibble(dat)

    } else {
      stop("Unsupported climate file format. Use csv, txt, tsv, tab, dat, xls, or xlsx.")
    }

  } else {
    stop("'x' must be either a data frame or a valid file path.")
  }

  if (ncol(dat) < 2) {
    stop("Climate input must contain at least one time column and one climate variable.")
  }

  # detect / parse time column
  if (is.null(time_col)) {
    det <- .dm_auto_find_time_col(dat, tz = tz, min_success = min_time_success)
    time_col <- det$time_col
    parsed_time <- det$parsed_time
  } else {
    if (!time_col %in% names(dat)) {
      stop(sprintf("Time column '%s' was not found in the input data.", time_col))
    }
    parsed_time <- .dm_parse_time_candidate(dat[[time_col]], tz = tz)

    valid_input <- if (is.character(dat[[time_col]]) || is.factor(dat[[time_col]])) {
      !is.na(dat[[time_col]]) & trimws(as.character(dat[[time_col]])) != ""
    } else {
      !is.na(dat[[time_col]])
    }

    success <- if (sum(valid_input) == 0) 0 else sum(!is.na(parsed_time) & valid_input) / sum(valid_input)
    if (success < min_time_success) {
      stop(
        "The supplied time column could not be parsed reliably. ",
        "Accepted examples: 'yyyy-mm-dd HH:MM:SS', 'yyyy-mm-dd', POSIXct, Date, Excel serial dates, Unix timestamps."
      )
    }
  }

  dat$TIME <- parsed_time

  if (all(is.na(dat$TIME))) {
    stop(
      "Could not parse the climate time column. ",
      "Accepted formats include POSIXct, Date, 'yyyy-mm-dd HH:MM:SS', and 'yyyy-mm-dd'."
    )
  }

  # remove original time column if needed
  if (time_col != "TIME") {
    dat[[time_col]] <- NULL
  }

  # keep only selected vars
  if (!is.null(vars)) {
    miss <- setdiff(vars, names(dat))
    if (length(miss) > 0) {
      stop(sprintf(
        "The following requested climate variables were not found: %s",
        paste(miss, collapse = ", ")
      ))
    }
    dat <- dat %>% dplyr::select(TIME, dplyr::all_of(vars))
  }

  # always put TIME first
  dat <- dat[, c("TIME", setdiff(names(dat), "TIME")), drop = FALSE]

  # sort by time
  dat <- dat[order(dat$TIME), , drop = FALSE]

  # remove duplicate timestamps
  if (drop_duplicate_time) {
    dup <- duplicated(dat$TIME)
    if (any(dup)) {
      dat <- dat[!dup, , drop = FALSE]
      warning("Duplicated timestamps were found and removed (first occurrence kept).")
    }
  }

  # try to coerce non-time columns to numeric where sensible
  for (nm in setdiff(names(dat), "TIME")) {
    dat[[nm]] <- .dm_maybe_numeric(dat[[nm]], dec = dec)
  }

  if (!any(vapply(dat[setdiff(names(dat), "TIME")], is.numeric, logical(1)))) {
    warning("None of the climate variables appear to be numeric after reading. Check separators, decimals, and input format.")
  }

  attr(dat, "timezone") <- tz
  attr(dat, "time_col_original") <- time_col
  class(dat) <- c("dm_clim", class(dat))

  if (verbose) {
    cat(
      "Climate data standardized.\n",
      "Rows:", nrow(dat), "\n",
      "Time column:", time_col, "\n",
      "Variables:", paste(setdiff(names(dat), "TIME"), collapse = ", "), "\n",
      "Time range:", format(min(dat$TIME, na.rm = TRUE)), "to", format(max(dat$TIME, na.rm = TRUE)), "\n"
    )
  }

  dat
}



#' @title Daily climate summaries for dendrometer analyses
#'
#' @description
#' Computes daily climate summaries from climate time series so they can be
#' related to daily dendrometer summaries from \code{daily.data()}.
#'
#' The input can be a standardized climate object returned by
#' \code{read.climate()}, a raw data frame, or a valid file path accepted by
#' \code{read.climate()}.
#'
#' In addition to same-day climate summaries, the function can also compute
#' lagged and antecedent daily climate features from the summarized daily series:
#' \itemize{
#'   \item lagged values (e.g. previous 1 or 3 days)
#'   \item antecedent means over previous \code{n} days
#'   \item antecedent sums over previous \code{n} days
#' }
#'
#' @details
#' Lagged and antecedent features are calculated from the already summarized
#' daily climate columns. For example, if \code{VPD} is included in
#' \code{max_vars}, the daily summary column will be \code{VPD_max}. If this
#' column is listed in \code{lag_vars} and \code{lag_days = 1}, then the
#' additional column \code{VPD_max_lag_1d} is created.
#'
#' Antecedent means and sums exclude the current day. For example:
#' \deqn{x\_lagmean\_3d(t) = mean(x_{t-3}, x_{t-2}, x_{t-1})}
#' \deqn{x\_lagsum\_7d(t) = sum(x_{t-7}, \ldots, x_{t-1})}
#'
#' @param clim_df Climate input. This can be:
#'   \itemize{
#'     \item a standardized object returned by \code{read.climate()}
#'     \item a raw data frame with a time column in the first column or in a
#'           column named \code{TIME}
#'     \item a valid file path readable by \code{read.climate()}
#'   }
#' @param mean_vars Character vector of variables to summarize by mean.
#' @param min_vars Character vector of variables to summarize by minimum.
#' @param max_vars Character vector of variables to summarize by maximum.
#' @param sum_vars Character vector of variables to summarize by sum.
#' @param median_vars Character vector of variables to summarize by median.
#' @param lag_vars Character vector of summarized daily climate columns for
#'   which simple lagged values should be computed, e.g.
#'   \code{c("VPD_max", "SWC_mean")}.
#' @param lagmean_vars Character vector of summarized daily climate columns for
#'   which antecedent means should be computed, e.g.
#'   \code{c("Tair_mean", "VPD_mean")}.
#' @param lagsum_vars Character vector of summarized daily climate columns for
#'   which antecedent sums should be computed, e.g.
#'   \code{c("P_sum", "Rad_sum")}.
#' @param lag_days Integer vector giving lag/antecedent window sizes in days,
#'   e.g. \code{c(1, 3, 7)}.
#'
#' @return A tibble of class \code{"daily_clim"} with one row per day.
#'
#' @examples
#' \donttest{
#' data(ktm_clim_hourly)
#' clim_day <- dm_daily_clim(
#'   ktm_clim_hourly,
#'   mean_vars = c("temp", "VPD", "RH"),
#'   max_vars  = c("VPD"),
#'   sum_vars  = c("prec"),
#'   lag_vars = c("VPD_max", "temp_mean"),
#'   lagmean_vars = c("temp_mean", "VPD_mean", "RH_mean"),
#'   lagsum_vars = c("prec_sum"),
#'   lag_days = c(1, 3, 7)
#' )
#' head(clim_day, 5)
#' }
#'
#' @export
dm_daily_clim <- function(clim_df,
                          mean_vars = NULL,
                          min_vars = NULL,
                          max_vars = NULL,
                          sum_vars = NULL,
                          median_vars = NULL,
                          lag_vars = NULL,
                          lagmean_vars = NULL,
                          lagsum_vars = NULL,
                          lag_days = c(1, 3, 7)) {
  TIME <- DATE <- NULL

  dat <- .dm_prepare_climate(clim_df, verbose = FALSE)
  numeric_vars <- setdiff(names(dat)[vapply(dat, is.numeric, logical(1))], "TIME")

  if (all(c(
    is.null(mean_vars), is.null(min_vars), is.null(max_vars),
    is.null(sum_vars), is.null(median_vars)
  ))) {
    mean_vars <- numeric_vars
  }

  check_vars <- function(vars, allowed, arg_name) {
    if (is.null(vars)) return(character(0))
    miss <- setdiff(vars, allowed)
    if (length(miss) > 0) {
      stop(sprintf(
        "Unknown or invalid variable(s) in %s: %s",
        arg_name, paste(miss, collapse = ", ")
      ))
    }
    vars
  }

  # raw climate vars to summarize
  mean_vars   <- check_vars(mean_vars, numeric_vars, "mean_vars")
  min_vars    <- check_vars(min_vars, numeric_vars, "min_vars")
  max_vars    <- check_vars(max_vars, numeric_vars, "max_vars")
  sum_vars    <- check_vars(sum_vars, numeric_vars, "sum_vars")
  median_vars <- check_vars(median_vars, numeric_vars, "median_vars")

  # helper for antecedent windows excluding current day
  antecedent_stat <- function(x, n, FUN) {
    out <- rep(NA_real_, length(x))
    n <- as.integer(n)

    if (n <= 0) return(out)
    if (length(x) <= n) return(out)

    for (i in seq_along(x)) {
      if (i > n) {
        out[i] <- .dm_safe_agg(x[(i - n):(i - 1)], FUN)
      }
    }
    out
  }

  # build daily summary first
  out <- dat %>%
    dplyr::mutate(DATE = as.Date(TIME)) %>%
    dplyr::group_by(DATE) %>%
    dplyr::summarise(
      dplyr::across(
        dplyr::all_of(mean_vars),
        ~ .dm_safe_agg(.x, mean),
        .names = "{.col}_mean"
      ),
      dplyr::across(
        dplyr::all_of(min_vars),
        ~ .dm_safe_agg(.x, min),
        .names = "{.col}_min"
      ),
      dplyr::across(
        dplyr::all_of(max_vars),
        ~ .dm_safe_agg(.x, max),
        .names = "{.col}_max"
      ),
      dplyr::across(
        dplyr::all_of(sum_vars),
        ~ .dm_safe_agg(.x, sum),
        .names = "{.col}_sum"
      ),
      dplyr::across(
        dplyr::all_of(median_vars),
        ~ .dm_safe_agg(.x, stats::median),
        .names = "{.col}_median"
      ),
      .groups = "drop"
    )

  # validate requested lag-based daily summary columns
  summary_cols <- setdiff(names(out), "DATE")
  lag_vars     <- check_vars(lag_vars, summary_cols, "lag_vars")
  lagmean_vars <- check_vars(lagmean_vars, summary_cols, "lagmean_vars")
  lagsum_vars  <- check_vars(lagsum_vars, summary_cols, "lagsum_vars")

  if (length(lag_days) > 0) {
    if (any(!is.finite(lag_days)) || any(lag_days <= 0)) {
      stop("'lag_days' must contain positive finite integers.")
    }
    lag_days <- sort(unique(as.integer(lag_days)))
  }

  # simple lags
  if (length(lag_vars) > 0 && length(lag_days) > 0) {
    for (v in lag_vars) {
      for (d in lag_days) {
        out[[paste0(v, "_lag_", d, "d")]] <- dplyr::lag(out[[v]], n = d)
      }
    }
  }

  # antecedent means
  if (length(lagmean_vars) > 0 && length(lag_days) > 0) {
    for (v in lagmean_vars) {
      for (d in lag_days) {
        out[[paste0(v, "_lagmean_", d, "d")]] <- antecedent_stat(out[[v]], d, mean)
      }
    }
  }

  # antecedent sums
  if (length(lagsum_vars) > 0 && length(lag_days) > 0) {
    for (v in lagsum_vars) {
      for (d in lag_days) {
        out[[paste0(v, "_lagsum_", d, "d")]] <- antecedent_stat(out[[v]], d, sum)
      }
    }
  }

  class(out) <- c("daily_clim", class(out))
  out
}


#' @title Subdaily climate features for dendrometer analyses
#'
#' @description
#' Computes rolling-window and lagged climate features at subdaily resolution
#' for direct linkage with point-level dendrometer outputs such as
#' \code{ZG_phase} and \code{SC_phase}.
#'
#' The input can be a standardized climate object returned by
#' \code{read.climate()}, a raw data frame, or a valid file path accepted by
#' \code{read.climate()}.
#'
#' @details
#' The function learns the temporal resolution automatically from the median
#' time step in the \code{TIME} column. It works with hourly as well as
#' minute-resolution data (for example 60-, 30-, 15-, 10-, or 5-minute data).
#'
#' Rolling windows and lags are provided in hours and may be fractional:
#' \itemize{
#'   \item \code{0.25} = 15 minutes
#'   \item \code{0.5} = 30 minutes
#'   \item \code{1} = 1 hour
#'   \item \code{3} = 3 hours
#' }
#'
#' If the user requests a rolling window or lag that is smaller than the
#' inferred climate resolution, the function stops with an error.
#'
#' If a requested window is not an exact multiple of the inferred resolution,
#' it is rounded to the nearest number of time steps and a warning is issued.
#'
#' @param clim_df Climate input. This can be:
#'   \itemize{
#'     \item a standardized object returned by \code{read.climate()}
#'     \item a raw data frame with a time column in the first column or in a
#'           column named \code{TIME}
#'     \item a valid file path readable by \code{read.climate()}
#'   }
#' @param mean_vars Variables for rolling means.
#' @param sum_vars Variables for rolling sums.
#' @param lag_vars Variables for lagged features.
#' @param roll_hours Numeric vector of rolling-window sizes in hours.
#'   Fractional values are allowed, e.g. \code{0.5} for 30 minutes.
#' @param lag_hours Numeric vector of lag sizes in hours.
#'   Fractional values are allowed, e.g. \code{0.25} for 15 minutes.
#' @examples
#' \donttest{
#' data(ktm_clim_hourly)
#'
#' clim_sub <- dm_subdaily_clim(
#'   ktm_clim_hourly,
#'   mean_vars = c("temp", "VPD", "RH"),
#'   sum_vars  = c("prec"),
#'   lag_vars  = c("temp", "VPD", "RH"),
#'   roll_hours = c(1, 3, 6, 24),
#'   lag_hours  = c(1, 3, 6, 24)
#' )
#'
#' head(clim_sub)
#' attr(clim_sub, "resolution_hours")
#' }
#' @return
#' A tibble of class \code{"subdaily_clim"} with timestamp-level climate
#' features added. The inferred temporal resolution in hours is stored in
#' \code{attr(x, "resolution_hours")}.
#'
#' @export
dm_subdaily_clim <- function(clim_df,
                             mean_vars = NULL,
                             sum_vars = NULL,
                             lag_vars = NULL,
                             roll_hours = c(3, 6, 24),
                             lag_hours = c(1, 3, 6, 24)) {

  dat <- .dm_prepare_climate(clim_df, verbose = FALSE)
  numeric_vars <- setdiff(names(dat)[vapply(dat, is.numeric, logical(1))], "TIME")

  if (all(c(is.null(mean_vars), is.null(sum_vars), is.null(lag_vars)))) {
    mean_vars <- numeric_vars
    lag_vars <- numeric_vars
  }

  check_vars <- function(vars, arg_name) {
    if (is.null(vars)) return(character(0))
    miss <- setdiff(vars, numeric_vars)
    if (length(miss) > 0) {
      stop(sprintf("Unknown or non-numeric variable(s) in %s: %s", arg_name, paste(miss, collapse = ", ")))
    }
    vars
  }

  mean_vars <- check_vars(mean_vars, "mean_vars")
  sum_vars  <- check_vars(sum_vars, "sum_vars")
  lag_vars  <- check_vars(lag_vars, "lag_vars")

  res_h <- .dm_resolution_hours(dat$TIME)
  if (is.na(res_h)) {
    stop("Could not infer temporal resolution from the climate time column.")
  }

  if (.dm_is_irregular(dat$TIME)) {
    warning("Climate data appear to have irregular temporal resolution. Rolling/lagged features are based on the median resolution.")
  }

  if (length(roll_hours) > 0 && any(roll_hours < res_h)) {
    stop(
      sprintf(
        "Requested rolling window(s) below the inferred climate resolution (%.6f h): %s",
        res_h,
        paste(roll_hours[roll_hours < res_h], collapse = ", ")
      )
    )
  }

  if (length(lag_hours) > 0 && any(lag_hours < res_h)) {
    stop(
      sprintf(
        "Requested lag(s) below the inferred climate resolution (%.6f h): %s",
        res_h,
        paste(lag_hours[lag_hours < res_h], collapse = ", ")
      )
    )
  }

  out <- dat

  # rolling means
  if (length(mean_vars) > 0 && length(roll_hours) > 0) {
    for (v in mean_vars) {
      for (h in roll_hours) {
        n_steps <- max(1L, as.integer(round(h / res_h)))
        if (abs((h / res_h) - n_steps) > 0.05) {
          warning(sprintf(
            "Rolling window %sh for '%s' is not an exact multiple of the inferred resolution (%.6f h); rounded to %s steps.",
            h, v, res_h, n_steps
          ))
        }
        out[[paste0(v, "_rollmean_", h, "h")]] <- .dm_roll_right(out[[v]], n_steps, mean)
      }
    }
  }

  # rolling sums
  if (length(sum_vars) > 0 && length(roll_hours) > 0) {
    for (v in sum_vars) {
      for (h in roll_hours) {
        n_steps <- max(1L, as.integer(round(h / res_h)))
        if (abs((h / res_h) - n_steps) > 0.05) {
          warning(sprintf(
            "Rolling window %sh for '%s' is not an exact multiple of the inferred resolution (%.6f h); rounded to %s steps.",
            h, v, res_h, n_steps
          ))
        }
        out[[paste0(v, "_rollsum_", h, "h")]] <- .dm_roll_right(out[[v]], n_steps, sum)
      }
    }
  }

  # lags
  if (length(lag_vars) > 0 && length(lag_hours) > 0) {
    for (v in lag_vars) {
      for (h in lag_hours) {
        n_steps <- max(1L, as.integer(round(h / res_h)))
        if (abs((h / res_h) - n_steps) > 0.05) {
          warning(sprintf(
            "Lag window %sh for '%s' is not an exact multiple of the inferred resolution (%.6f h); rounded to %s steps.",
            h, v, res_h, n_steps
          ))
        }
        out[[paste0(v, "_lag_", h, "h")]] <- .dm_lag_vec(out[[v]], n_steps)
      }
    }
  }

  attr(out, "resolution_hours") <- res_h
  class(out) <- c("subdaily_clim", class(out))
  out
}
