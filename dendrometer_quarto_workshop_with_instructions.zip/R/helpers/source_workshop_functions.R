# Source all workshop functions -----------------------------------------
# The original uploaded files are copied unchanged to R/functions/.

source_workshop_functions <- function(
  functions_dir = here::here("R", "functions"),
  envir = .GlobalEnv,
  verbose = TRUE
) {
  if (!dir.exists(functions_dir)) {
    stop("Function directory not found: ", functions_dir, call. = FALSE)
  }

  files <- list.files(functions_dir, pattern = "\\.R$", full.names = TRUE)

  # Source import helpers first so setup code can use them immediately.
  priority <- c("read.dendrometer.R", "climate_functions.R")
  files <- c(
    files[basename(files) %in% priority],
    files[!basename(files) %in% priority]
  )
  files <- unique(files)

  # Some uploaded files define helper names such as mean(), max(), min(), sum().
  # They are kept unchanged, but this note helps workshop participants understand
  # why base::mean() may be safer in their own code after sourcing everything.
  conflict_names <- c("mean", "max", "min", "sum")

  for (f in files) {
    if (verbose) message("Sourcing: ", basename(f))
    source(f, local = envir)
  }

  if (verbose && any(conflict_names %in% ls(envir))) {
    message(
      "Note: some uploaded helper functions use base function names. ",
      "Use base::mean(), base::max(), base::min(), or base::sum() when needed."
    )
  }

  invisible(files)
}
