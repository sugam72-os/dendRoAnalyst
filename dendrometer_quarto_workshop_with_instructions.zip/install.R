# install.R -------------------------------------------------------------
# Run once before the workshop.

required_packages <- c(
  "tidyverse", "lubridate", "zoo", "forecast", "WaveletComp", "here",
  "conflicted", "readxl", "readr", "minpack.lm", "mgcv", "changepoint",
  "boot", "pspline", "signal", "quarto", "knitr", "rmarkdown"
)

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  install.packages(missing_packages, dependencies = TRUE)
}

optional_packages <- c("dendRoAnalyst")
optional_missing <- optional_packages[
  !vapply(optional_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(optional_missing) > 0) {
  message(
    "Optional package(s) not installed: ", paste(optional_missing, collapse = ", "),
    "\nThe workshop can still use the local functions in R/functions/."
  )
}

message("Installation check complete.")
