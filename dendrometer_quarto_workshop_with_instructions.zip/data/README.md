# Data folder

Place workshop datasets in `data/raw/`.

Automatic loading looks for dendrometer files with names such as:

- `dm.csv`, `dm.tsv`, `dm.txt`, `dm.xlsx`
- `dendrometer.csv`, `dendrometer.tsv`, `dendrometer.txt`, `dendrometer.xlsx`
- `dendrometer_data.csv`, `dendrometer_data.tsv`, `dendrometer_data.txt`, `dendrometer_data.xlsx`
- `nepa17.csv`, `nepa17.tsv`, `nepa17.txt`, `nepa17.xlsx`

Automatic loading looks for climate files with names such as:

- `clim.csv`, `clim.tsv`, `clim.txt`, `clim.xlsx`
- `climate.csv`, `climate.tsv`, `climate.txt`, `climate.xlsx`
- `climate_data.csv`, `climate_data.tsv`, `climate_data.txt`, `climate_data.xlsx`
- `ktm_clim_hourly.csv`, `ktm_clim_hourly.tsv`, `ktm_clim_hourly.txt`, `ktm_clim_hourly.xlsx`

Explicit loading is also supported:

```r
workshop_data <- load_workshop_data(
  dm_file = "data/raw/my_dendrometer.csv",
  clim_file = "data/raw/my_climate.csv"
)
```
