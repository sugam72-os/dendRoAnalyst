#' Interpolation of NA value using dendrometer network
#'
#' To interpolate the missing data of a dendrometer with the help of other dendrometers from same site provided that they must have same measurement period and temporal resolution.
#'
#' @param df dataframe with first column containing Time with the format 'yyyy-mm-dd HH:MM:SS' and dendrometer data from second column onward.The data gaps must be filled with NA using gap.interpolation function.
#'
#' @param referenceDF Dataframe with other dendrometers to be used as reference for interpolation. More dendrometers should be included to get robust interpolation.
#'
#' @param niMethod string, either 'linear' or 'proportional' for interpolation method.
#'
#' @return A dataframe with NA replaced with interpolated data.
#'
#' @examples library(dendRoAnalyst)
#' data("gf_nepa17")
#' df1<-gf_nepa17
#' # Creating an artificial reference dataset.
#' df2<-cbind(gf_nepa17,gf_nepa17[,2:3],gf_nepa17[,2:3])
#' # Creating gaps in dataset by replacing some of the reading with NA in dataset.
#' df1[40:50,2]<-NA
#' df1[140:150,3]<-NA
#' # Using proportional interpolation method.
#' df1_NI<-network.interpolation(df=df1, referenceDF=df2, niMethod='proportional')
#' head(df1_NI,10)
#'
#' @importFrom stats approx median na.exclude na.omit sd lm
#'
#' @importFrom boot boot boot.ci
#'
#' @export
network.interpolation<-function(df,referenceDF,niMethod){
  df1<-df
  if(ncol(df)<=2){
    df$x<-df[,2]
  }

  df2<-referenceDF
  meth<-niMethod
  for(i in 2:ncol(df1)){
    f.loc<-which(is.na(df1[,i]))
    r.sq<-c()
    tm<-c()
    inp.v<-c()
    ul<-c()
    ll<-c()
    for(j in f.loc){
      ref.j<-c(t(df2[j,2:ncol(df2)]))
      ref.pj<-c(t(df2[(j-1),2:ncol(df2)]))
      ref.pj[ref.pj==0]<-0.001
      if(meth=='linear'){
        xy<-function(df,i){
          df2<-df[i,]
          lml<-lm(df2)
          d<-c(summary(lml)$adj.r.squared,lml$coefficients[2], lml$coefficients[1])
          return(d)
        }
        xy1<-function(df,i){
          df2<-df[i,]
          lml<-lm(df2)
          d<-lml$coefficients[2]
          return(d)
        }
        xy2<-function(df,i){
          df2<-df[i,]
          lml<-lm(df2)
          d<-lml$coefficients[1]
          return(d)
        }
        A1<-boot::boot(data.frame(ref.pj,ref.j),statistic =xy,R=500)
        A2<-boot::boot(data.frame(ref.pj,ref.j),statistic =xy1,R=500)#slope
        A3<-boot::boot(data.frame(ref.pj,ref.j),statistic =xy2,R=500)#intercept
        B2<-boot::boot.ci(A2, conf=0.95, type="bca")
        B3<-boot::boot.ci(A3, conf=0.95, type="bca")
        #lm.j<-lm(ref.j~ref.pj)
        r.sq<-c(r.sq,A1$t0[1])
        df1[j,i]<-df1[(j-1),i]*A1$t0[2]+A1$t0[3]
        tm<-c(tm,df1[j,1])
        inp.v<-c(inp.v,df1[j,i])
        ul<-c(ul,df1[(j-1),i]*B2$bca[5]+B3$bca[5])
        ll<-c(ll,df1[(j-1),i]*B2$bca[4]+B3$bca[4])
      }else{
        if(meth=='proportional'){
          fc <- function(d, i){
            d2 <- d[i]
            return(mean(d2, na.rm = T))
          }
          ref.d<-as.numeric((ref.j-ref.pj)/ref.pj)
          p_ref.d<-df1[(j-1),i]+(df1[(j-1),i]*ref.d)
          A<-boot::boot(p_ref.d,statistic = fc,R=500)
          B<-boot::boot.ci(A, conf=0.95, type="bca")
          #print(mean(ref.d))
          df1[j,i]<-A$t0
          tm<-c(tm,df1[j,1])
          inp.v<-c(inp.v,df1[j,i])
          ul<-c(ul, B$bca[5])
          ll<-c(ll, B$bca[4])
        }else{
          stop("Invalid niMethod provided. Please choose either 'linear' or 'proportional'.")
        }

      }
    }
    print(paste('Interpolation in', colnames(df1)[i]))
    print(data.frame('Time'=tm, 'Interpolated_value'=inp.v, 'Lower.CI95'=ll, 'Upper.CI95'=ul, 'R.sq'=ifelse(meth=='linear',r.sq,NA)))

  }
  if(ncol(df)<=2){
    df1$x<-NULL
  }
  return(df1)
}
